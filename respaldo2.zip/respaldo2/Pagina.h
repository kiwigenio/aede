#ifndef PAGINA_H
#define PAGINA_H

#include <vector>
#include <string>
#include <iostream>

class Pagina {
public:
    std::vector<std::string> sectores; // Rutas de los sectores que componen la página


    void agregarSector(const std::string& rutaSector);
    void mostrarSectores() const;
    const std::vector<std::string>& obtenerSectores() const;
    const std::vector<std::string>& getSectores() const {
    return sectores;
    }

};

#endif
