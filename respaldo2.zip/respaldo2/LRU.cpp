#include "LRU.h"
#include "Frame.h"

int LRU::seleccionarVictima(const std::vector<std::shared_ptr<Frame>>& frames) {
    int victima = -1;
    auto tiempoMasAntiguo = std::chrono::steady_clock::now();

    for (const auto& [frameID, tiempo] : accesos) {
        if (frameID >= frames.size()) continue;
        auto frame = frames[frameID];

        if (frame->isPinned()) continue;

        if (victima == -1 || tiempo < tiempoMasAntiguo) {
            victima = frameID;
            tiempoMasAntiguo = tiempo;
        }
    }

    return victima;
}