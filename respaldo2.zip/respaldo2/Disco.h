#ifndef DISCO_H
#define DISCO_H

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Disco{
    public:
    int platos;
    int pistas;
    int sectores;

    void crearDirectorio(string);
    void crearDisco(int, int, int);

};

#endif