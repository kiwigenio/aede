#include "BufferManager.h"

void BufferManager::cargarPaginaEnBuffer(const Pagina& pagina) {
    auto frame = std::make_shared<Frame>(frameSize);  // crea un frame con tamaño definido
    frame->setPagina(pagina); // método que debes tener en Frame
    bufferPool->addFrame(frame);
}
/*
void BufferManager::cargarPaginaAlBuffer(const Pagina& pagina, int pageID, bool esEscritura) {
    auto frame = std::make_shared<Frame>(frameSize);
    frame->setPagina(pagina);
    frame->setPageID(pageID);
    frame->setDirty(esEscritura);
    frame->pin();  // actualiza dirtyBit según operación
    frame->updateLastUsed();
    bufferPool->addFrame(frame);
    std::cout << "Página " << pageID << " cargada al buffer como "
              << (esEscritura ? "escritura" : "lectura") << ".\n";
}
*/
void BufferManager::cargarPaginaAlBuffer(const Pagina& pagina, int pageID, bool esEscritura) {
    std::string tipo = esEscritura ? "Escritura" : "Lectura";
    solicitudPorPagina[pageID].push(tipo); // ← agrega a la cola

    // Verificar si la página ya está cargada
    for (auto& frame : bufferPool->getFrames()) {
        if (frame->getPageID() == pageID) {
            frame->pin(); 
            frame->setReferenced(true);

            // Procesa solo la solicitud al frente
            if (!solicitudPorPagina[pageID].empty()) {
                std::string actual = solicitudPorPagina[pageID].front();
                if (actual == "Lectura") {
                    frame->setDirty(false);
                } else {
                    frame->setDirty(true);
                }
                solicitudPorPagina[pageID].pop(); // quita la solicitud procesada
            }

            return;
        }
    }

    // Si no está cargada, crea nuevo frame
    auto frame = std::make_shared<Frame>(frameSize);
    frame->setPagina(pagina);
    frame->setPageID(pageID);
    frame->pin();
    frame->setReferenced(true);

    // Procesa la solicitud al frente
    if (!solicitudPorPagina[pageID].empty()) {
        std::string actual = solicitudPorPagina[pageID].front();
        frame->setDirty(actual == "Escritura");
        solicitudPorPagina[pageID].pop(); 
    }

    if (bufferPool->estaLleno()) {
        bufferPool->reemplazarFrame(frame);
    } else {
        bufferPool->addFrame(frame);
    }
}


std::shared_ptr<Frame> BufferManager::getFrameByPageID(int pageID) {
    for (const auto& frame : bufferPool->getFrames()) {
        if (frame->getPageID() == pageID) {
            return frame;
        }
    }
    return nullptr;
}



