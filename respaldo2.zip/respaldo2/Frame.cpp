#include "Frame.h"

void Frame::setPagina(const Pagina& pagina) {
    this->pagina = pagina;
    // aquí puedes copiar datos si es necesario
}
