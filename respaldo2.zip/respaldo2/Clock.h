#ifndef CLOCK_H
#define CLOCK_H

#include "PoliticaReemplazo.h"
#include "Frame.h"
#include "BufferPool.h"
#include <vector>
#include <memory>
#include <unordered_map>
#include <queue>
#include <iostream>

class Clock : public PoliticaReemplazo {
private:
    std::vector<bool> referencia;
    size_t puntero = 0;
    std::unordered_map<int, std::queue<std::string>>* solicitudes;
    BufferPool* bufferPool;

public:
    void setSolicitudes(std::unordered_map<int, std::queue<std::string>>* s) {
        solicitudes = s;
    }

    void setBufferPool(BufferPool* pool) {
        bufferPool = pool;
    }

    void registrarAcceso(int frameId) override {
        if (frameId >= referencia.size()) {
            referencia.resize(frameId + 1, false);
        }
        referencia[frameId] = true;
    }

    int seleccionarVictima(const std::vector<std::shared_ptr<Frame>>& frames) override {
        size_t totalFrames = frames.size();
        if (totalFrames == 0 || !solicitudes || !bufferPool) return -1;

        std::cout << "\n[POLÍTICA CLOCK ACTIVADA]\n";

        size_t vueltas = 0;
        while (vueltas < 2 * totalFrames) {
            auto& frame = frames[puntero];
            int frameID = puntero;
            int pageID = frame->getPageID();
            bool seDespino = false;

            std::cout << "➡ Aguja en Frame " << frameID << " (Página " << pageID << ")\n";

            int pinAntes = frame->getPinCount();
            if (pinAntes > 0) {
                frame->unpin();
                std::cout << "  - PinCount reducido: " << pinAntes << " → " << frame->getPinCount() << "\n";
                seDespino = true;
            }

            // Procesar primera solicitud de la cola
            if (solicitudes->count(pageID)) {
                auto& cola = (*solicitudes)[pageID];
                if (!cola.empty()) {
                    std::string procesada = cola.front();
                    
                    std::cout << "  - Procesada solicitud: " << procesada << "\n";
                    cola.pop();
                }

                if (!cola.empty()) {
                    std::string siguiente = cola.front();
                    frame->setDirty(siguiente == "Escritura");
                    std::cout << "  - Nueva al frente: " << siguiente
                              << " → dirty = " << (frame->isDirty() ? 1 : 0) << "\n";
                } else {
                    frame->setDirty(false);
                    std::cout << "  - Sin solicitudes → dirty = 0\n";
                }
            }

            // Limpieza del bit de referencia si pinCount == 0
            if (frame->getPinCount() == 0 && referencia[frameID]) {
                std::cout << "  - Bit de referencia limpiado\n";
                referencia[frameID] = false;
                frame->setReferenced(false); // << sincroniza con el Frame
            } else {
                frame->setReferenced(referencia[frameID]); // actualiza valor visible en Page Table
            }

            // Mostrar Page Table
            bufferPool->mostrarPageTable();

            if (frame->getPinCount() == 0 && referencia[frameID] == false && !seDespino) {
                std::cout << "✅ Frame " << frameID << " seleccionado como víctima.\n";
                int victima = frameID;
                puntero = (puntero + 1) % totalFrames;
                return victima;
            }

            puntero = (puntero + 1) % totalFrames;
            vueltas++;
        }

        std::cout << "❌ No se encontró víctima válida.\n";
        return -1;
    }
};

#endif
