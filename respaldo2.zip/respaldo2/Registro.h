#ifndef REGISTRO_H
#define REGISTRO_H

#include <iostream>
using namespace std;

class Registro{
    public:
    void insertarLongitudFija();
    void insertarLongitudVariable();
    void eliminarRegistro();

};

#endif