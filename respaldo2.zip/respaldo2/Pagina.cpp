#include "Pagina.h"

void Pagina::agregarSector(const std::string& rutaSector) {
    sectores.push_back(rutaSector);
}

void Pagina::mostrarSectores() const {
    std::cout << "Página compuesta por sectores:\n";
    for (const auto& ruta : sectores) {
        std::cout << "  - " << ruta << "\n";
    }
}

const std::vector<std::string>& Pagina::obtenerSectores() const {
    return sectores;
}
