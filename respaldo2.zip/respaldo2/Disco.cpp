#include "Disco.h"




void Disco::crearDirectorio(string ruta) {
    string comando = "mkdir \"" + ruta + "\"";
    system(comando.c_str());
}

void Disco::crearDisco(int discos, int pistasPorSuperficie, int sectoresPorPista){

    crearDirectorio("disco sgbd");

    for(int d = 1; d <= discos; d++){
        string rutaDisco = "disco sgbd/disco " + to_string(d);
        crearDirectorio(rutaDisco);

        for(int s = 1; s <= 2; s++){
            string rutaSup = rutaDisco + "/superficie " + to_string(s);
            crearDirectorio(rutaSup);

            for(int p = 1; p <= pistasPorSuperficie; p++){
                string rutaPista = rutaSup + "/pista " + to_string(p);
                crearDirectorio(rutaPista);

                for(int se = 1; se <= sectoresPorPista; se++){
                    string rutaSector = rutaPista + "/sector " + to_string(se) + ".txt";
                    ofstream sector(rutaSector.c_str());
                    sector.close();
                }
            }
        }
    }


    int tamSector;
    cout << "Tamano de un sector (bytes): ";
    cin >> tamSector;


    int capDisco = discos * 2 * pistasPorSuperficie * sectoresPorPista * tamSector;
    cout << "\n";
    cout << "Disco simulado correctamente" << endl;
    cout << "Capacidad total del disco: " << capDisco << " B" << endl;
    cin.ignore();

}