#ifndef BUFFERMANAGER_H
#define BUFFERMANAGER_H

#include <iostream>
#include <memory>
#include <queue>
#include <unordered_map>

#include "BufferPool.h"
#include "LRU.h"
#include "Clock.h"
#include "Pagina.h"
#include "Frame.h"
using namespace std;

class BufferManager
{
public:
    std::shared_ptr<LRU> lru;
    // BufferPool bufferPool;
    std::unique_ptr<BufferPool> bufferPool;
    size_t frameSize;
    std::unordered_map<int, std::queue<std::string>> solicitudPorPagina;

    BufferManager() = default;
    void cargarPaginaEnBuffer(const Pagina &pagina);

    /*void initialize(size_t numFrames, size_t frameSize) {
        lru = std::make_shared<LRU>();
        //bufferPool = std::make_unique<BufferPool>(lru);
        bufferPool = std::unique_ptr<BufferPool>(new BufferPool(lru));


        for (size_t i = 0; i < numFrames; ++i) {
            bufferPool->addFrame(std::make_shared<Frame>(frameSize));
        }
    }*/

void initialize(size_t numFrames, size_t frameSize)
{
    int opcionPolitica;
    cout << "Seleccione política de reemplazo:\n1. LRU\n2. CLOCK\nOpción: ";
    cin >> opcionPolitica;

if (opcionPolitica == 1) {
    lru = std::make_shared<LRU>();
    bufferPool = std::make_unique<BufferPool>(lru, numFrames);
} else {
    auto clock = std::make_shared<Clock>();
    clock->setSolicitudes(&solicitudPorPagina);
    bufferPool = std::make_unique<BufferPool>(clock, numFrames);
    bufferPool->setSolicitudes(&solicitudPorPagina);  // ← ¡conecta las solicitudes!

    clock->setBufferPool(bufferPool.get()); // ← Aquí le das acceso al Page Table
}


    this->frameSize = frameSize;
}


    void showBufferStatus() const
    {
        if (bufferPool)
        {
            bufferPool->printInfo();
        }
        else
        {
            std::cout << "BufferPool no ha sido inicializado." << std::endl;
        }
    }

    void accederFrame(int id)
    {
        if (bufferPool)
            bufferPool->accederFrame(id);
    }

    void reemplazarFrame(size_t frameSize)
    {
        if (bufferPool)
        {
            bufferPool->reemplazarFrame(std::make_shared<Frame>(frameSize));
        }
    }

    void showPageTable() const
    {
        if (bufferPool)
            bufferPool->mostrarPageTable();
        else
            std::cout << "BufferPool no inicializado.\n";
    }
    void cargarPaginaAlBuffer(const Pagina &pagina, int pageID, bool esEscritura);

    /*BufferManager(size_t numFrames, size_t frameSize)
        : lru(std::make_shared<LRU>()), bufferPool(BufferPool(lru)) {
        for (size_t i = 0; i < numFrames; ++i) {
            bufferPool.addFrame(std::make_shared<Frame>(frameSize));
        }
    }

    void accederFrame(int id) {
        bufferPool.accederFrame(id);
    }

    void reemplazarFrame(size_t frameSize) {
        bufferPool.reemplazarFrame(std::make_shared<Frame>(frameSize));
    }

    void mostrarEstado() {
        bufferPool.printInfo();
    }*/

    /*void initialize(size_t numFrames, size_t frameSize) {
        for (size_t i = 0; i < numFrames; ++i) {
            std::shared_ptr<Frame> frame = std::make_shared<Frame>(frameSize);
            bufferPool.addFrame(frame);
        }
    }

    void showBufferStatus() const {
        bufferPool.printInfo();
    }*/

    const vector<shared_ptr<Frame>>& getFrames() const {
    return bufferPool->getFrames(); // O accede directo si es público
}
std::shared_ptr<Frame> getFrameByPageID(int pageID);

BufferPool& getBufferPool() {
    return *bufferPool;
}

std::vector<std::shared_ptr<Frame>> getFramesEscritura() {
    std::vector<std::shared_ptr<Frame>> escritura;
    for (const auto& frame : bufferPool->getFrames()) {
        if (frame->isDirty()) escritura.push_back(frame);
    }
    return escritura;
}



};

#endif