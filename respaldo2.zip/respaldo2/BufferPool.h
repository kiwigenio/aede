#ifndef BUFFERPOOL_H
#define BUFFERPOOL_H

#include <iostream>
#include <vector>
#include <memory>
#include <unordered_map>
#include <queue>
#include "PoliticaReemplazo.h"
#include "Frame.h"

using namespace std;

class BufferPool{
    public:
    size_t maxFrames;    
    vector<std::shared_ptr<Frame>> frames;
    std::shared_ptr<PoliticaReemplazo> politica;
    BufferPool(std::shared_ptr<PoliticaReemplazo> pol, size_t maxFrames) : politica(pol), maxFrames(maxFrames) {}
    std::unordered_map<int, std::queue<std::string>>* solicitudes = nullptr;
    void setSolicitudes(std::unordered_map<int, std::queue<std::string>>* s) {
    solicitudes = s;
    }

    /*void addFrame(std::shared_ptr<Frame> frame) {
        int id = frames.size();
        frames.push_back(frame);
        politica->registrarAcceso(id);
    }*/
   /*
    void addFrame(std::shared_ptr<Frame> frame) {
    int id = frames.size();
    frame->setFrameID(id);
    frames.push_back(frame);
    politica->registrarAcceso(id);
}*/

    void addFrame(std::shared_ptr<Frame> frame) {
        // Hay espacio libre en el buffer pool
        if (frames.size() < maxFrames) {
            frame->setFrameID(frames.size());
            politica->registrarAcceso(frames.size());
            frames.push_back(frame);
        } else {
            // Buffer lleno: se debe reemplazar un frame
            int victima = politica->seleccionarVictima(frames);

            // Si está fijado (pinned), no podemos reemplazarlo
            if (frames[victima]->isPinned()) {
                std::cout << "No se puede reemplazar el frame " << victima << " porque está fijado.\n";
                return;
            }

            std::cout << "Reemplazando frame " << victima << " por nueva página.\n";

            // Sobrescribimos el frame víctima con el nuevo
            frame->setFrameID(victima);
            frames[victima] = frame;
            politica->registrarAcceso(victima);
        }
    }



    void accederFrame(int frameId) {
        if (frameId >= 0 && frameId < frames.size()) {
            std::cout << "Accediendo al Frame " << frameId << "\n";
            politica->registrarAcceso(frameId);
        }
    }

    /*
    void reemplazarFrame(std::shared_ptr<Frame> nuevoFrame) {
        int victima = politica->seleccionarVictima();
        if (victima != -1) {
            std::cout << "Reemplazando Frame " << victima << "\n";
            frames[victima] = nuevoFrame;
            politica->registrarAcceso(victima);
        } else {
            std::cout << "No hay víctima para reemplazo.\n";
        }
    }*/

    void reemplazarFrame(std::shared_ptr<Frame> nuevoFrame) {
    int victimaId = politica->seleccionarVictima(frames);

    if (victimaId == -1) {
        std::cout << "No hay páginas reemplazables disponibles (todas están pinned)." << std::endl;
        return;
    }

    auto victima = frames[victimaId];
    frames[victimaId] = nuevoFrame;

    // Registrar acceso
    politica->registrarAcceso(nuevoFrame->getFrameID());
}


    void printInfo() const {
        cout << "BufferPool contiene " << frames.size() << " frames:\n";
        for (size_t i = 0; i < frames.size(); ++i) {
            cout << "  Frame " << i << ": tamaño = " << frames[i]->getSize() << " bytes\n";
        }
    }

void mostrarPageTable() const {
    std::cout << "\n--- Page Table ---\n";
    std::cout << "FrameID | PageID | Dirty | PinCount | Referenced\n";
    for (const auto& frame : frames) {
        int pageID = frame->getPageID();

        // Determinar dirty real según lo que esté al frente de la cola
        int dirtyLogico = 0;
        if (solicitudes && solicitudes->count(pageID)) {
            auto& cola = (*solicitudes)[pageID];
            if (!cola.empty()) {
                dirtyLogico = (cola.front() == "Escritura") ? 1 : 0;
            }
        }

        std::cout << "   " << frame->getFrameID()
                  << "     |   " << pageID
                  << "    |   " << dirtyLogico
                  << "     |    " << frame->getPinCount()
                  << "       |     " << (frame->isReferenced() ? 1 : 0) << "\n";
    }
    std::cout << "-------------------\n";
}



const std::vector<std::shared_ptr<Frame>>& getFrames() const {
    return frames;
}

bool estaLleno() const {
    return frames.size() >= maxFrames;
}
/*
const vector<shared_ptr<Frame>>& getFrames() const {
    return frames;
}
*/

std::shared_ptr<Frame> obtenerFramePorPageID(int pageID) {
    for (auto& frame : frames) {
        if (frame->getPageID() == pageID) {
            return frame;
        }
    }
    return nullptr;
}


};

#endif