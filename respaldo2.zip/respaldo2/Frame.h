#ifndef FRAME_H
#define FRAME_H

#include <iostream>
#include <vector>
#include <chrono>
#include <string>
#include "Pagina.h"
using namespace std;

class Frame{
    public:
    int frameID;
    int pageID;
    bool dirtyBit;
    int pinCount;
    bool referenced = false; 
    std::chrono::steady_clock::time_point lastUsedTime;
    size_t size;
    Pagina pagina;
    
    void setReferenced(bool r) { referenced = r; }
    bool isReferenced() const { return referenced; }

    Frame(size_t size)
        : /*frameID(-1),*/ pageID(-1), dirtyBit(false), pinCount(0),
          lastUsedTime(std::chrono::steady_clock::now()), size(size) {}

    void setFrameID(int id) { frameID = id; }
    void setPageID(int pid) { pageID = pid; }
    void setDirty(bool dirty) { dirtyBit = dirty; }
    void pin() { pinCount++; }
    void unpin() { if (pinCount > 0) pinCount--; }
    void updateLastUsed() { lastUsedTime = std::chrono::steady_clock::now(); }

    int getFrameID() const { return frameID; }
    int getPageID() const { return pageID; }
    bool isDirty() const { return dirtyBit; }
    int getPinCount() const { return pinCount; }
    bool isPinned() const { return pinCount > 0; }
    std::chrono::steady_clock::time_point getLastUsed() const { return lastUsedTime; }

    void printInfo() const {
        std::cout << "FrameID: " << frameID
                  << ", PageID: " << pageID
                  << ", Dirty: " << (dirtyBit ? "Yes" : "No")
                  << ", PinCount: " << pinCount
                  << ", IsPinned: " << (isPinned() ? "Yes" : "No")
                  << std::endl;
    }

    size_t getSize() const { return size; }
    void setPagina(const Pagina& pagina);

    /*vector<char> data;  // Espacio de datos del frame
    Frame(size_t size) : data(size) {}
    size_t getSize() const { return data.size(); }  */
    const Pagina& getPagina() const {
    return pagina;
}

Pagina& getPaginaRef() {
    return pagina;
}
/*
void setPagina(const Pagina& pag) {
    pagina = pag;
}*/

    
};

#endif