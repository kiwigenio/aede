#ifndef LRU_H
#define LRU_H


#include "PoliticaReemplazo.h"
#include <unordered_map>
#include <chrono>
#include <memory>
#include <list>


class LRU : public PoliticaReemplazo {
private:
    std::list<int> lruList; // Lista de uso reciente: el frente es el menos usado
    std::unordered_map<int, std::list<int>::iterator> map;

public:
    public:
        std::unordered_map<int, std::chrono::steady_clock::time_point> accesos;

    
        void registrarAcceso(int frameID) override {
            accesos[frameID] = std::chrono::steady_clock::now();
        }

        int seleccionarVictima(const std::vector<std::shared_ptr<Frame>>& frames) override;


    /*void registrarAcceso(int frameId) override {
        // Si ya está, lo movemos al final
        if (map.find(frameId) != map.end()) {
            lruList.erase(map[frameId]);
        }
        lruList.push_back(frameId);
        map[frameId] = std::prev(lruList.end());
    }*/
/*
    int seleccionarVictima() override {
        if (lruList.empty()) return -1;
        int victim = lruList.front();
        lruList.pop_front();
        map.erase(victim);
        return victim;
    }*/

    /*
    int seleccionarVictima(const std::vector<std::shared_ptr<Frame>>& frames) {
    int victima = -1;
    auto tiempoMasAntiguo = std::chrono::steady_clock::now();

    for (const auto& [frameID, tiempo] : accesos) {
        if (frameID >= frames.size()) continue; // Evitar out-of-bounds
        auto frame = frames[frameID];
        
        if (frame->isPinned()) continue; // No considerar pinned

        if (victima == -1 || tiempo < tiempoMasAntiguo) {
            victima = frameID;
            tiempoMasAntiguo = tiempo;
        }
    }

    return victima;  // -1 si no hay víctimas válidas
}*/



};



#endif