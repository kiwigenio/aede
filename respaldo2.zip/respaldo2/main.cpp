#include <iostream>
#include "Disco.h"
#include "Esquema.h"
#include "BufferManager.h"
#include "ControladorDisco.h"




using namespace std;



int main(){
    int opcion;

    int platos;
    int pistas;
    int sectores;
    
    Disco disco;
    Esquema esquema;
    BufferManager bm;
    ControladorDisco cd; // Se crea desde el inicio
    bool cdInicializado = false; // Bandera para saber si ya se configuró

    cout << endl;
    cout << "MEGATRON" << endl;
    while(true){
        cout << endl;
        cout << "MENU" << endl;
        cout << "1. Generar Disco" << endl;
        cout << "2. Ingresar Tabla" << endl;
        cout << "3. Insertar Registros" << endl;
        cout << "4. Inicializar BufferPool" << endl;
        cout << "5. Mostrar PageTable" << endl;
        cout << "6. Generar páginas desde sectores" << endl;
        //cout << "7. Cargar página al BufferPool" << endl;
        cout << "8. Cargar página al BufferPool final" << endl;
        cout << "9. Leer Paginas" << endl;
        cout << "10. Escritura Paginas" << endl;
        cout << "11. Borrar disco" << endl;
        cout << "12. Finalizar" << endl;

        cout << "opcion: ";
        cin >> opcion;

        if(opcion == 1){
            cout << "Platos: ";
            cin >> platos;
            cout << "Pistas por plato: ";
            cin >> pistas;
            cout << "Sectores por pista: ";
            cin >> sectores;
            disco.crearDisco(platos, pistas, sectores);
            cd = ControladorDisco(platos, pistas, sectores); // lo inicializas aquí
            cdInicializado = true;

        } else if(opcion == 2){
            string nombreTabla;
            int nroCamposTabla;
            cout << "Nombre para la tabla: ";            
            cin >> nombreTabla;
            cout << "numero de atributos: ";
            cin >> nroCamposTabla;
            esquema.agregarTabla(nombreTabla, nroCamposTabla);

        } else if(opcion == 3){
            string tablaAIngresar;
            int tipoRegistro = 0;
            cout << "Tablas disponibles: " << endl;
            esquema.imprimirEsquema();
            cout << "Escoja la tabla a la cual quiere ingresar el registro: ";            
            cin >> tablaAIngresar;

            cout << "Escoja el tipo de registro: ";
            cout << "1. Registro de Longitud Fija" << endl;
            cout << "2. Registro de Longitud Variable" << endl;
            cin >> tipoRegistro;

            //if(tipoRegistro == 1) insertarLongitudFija();
            //else if (tipoRegistro == 2) insertarLongitudVariable();


            


        } else if(opcion == 4){
            size_t numFrames, frameSize;

            std::cout << "Ingrese la cantidad de frames: ";
            std::cin >> numFrames;

            std::cout << "Ingrese el tamaño de cada frame (en bytes): ";
            std::cin >> frameSize;

            
            bm.initialize(numFrames, frameSize);
            bm.showBufferStatus();

            //bm.mostrarEstado();

            // Simulamos accesos
            bm.accederFrame(1);
            bm.accederFrame(2);
            bm.accederFrame(0);
            bm.accederFrame(1);
            bm.accederFrame(1);
            bm.accederFrame(5);
            bm.accederFrame(1);
            bm.accederFrame(7);
            bm.accederFrame(1);
            bm.accederFrame(3);

            // Simulamos reemplazo (lógica LRU decidirá cuál)
            //bm.reemplazarFrame(frameSize);
            bm.showBufferStatus();


        
        } else if(opcion == 5) {
            bm.showPageTable();
        
        } else if (opcion == 6) {
            if (cdInicializado) {
                int sectoresPorPagina;
                cout << "Sectores por página: ";
                cin >> sectoresPorPagina;
                cd.generarPaginas(sectoresPorPagina);
                cd.mostrarPaginas();
            } else {
                cout << "Primero debe generar el disco (opción 1).\n";
            }

        
        } else if (opcion == 7) {
            if (cd.paginas.empty()) {
                std::cout << "No hay páginas generadas aún.\n";
            } else {
                bm.cargarPaginaEnBuffer(cd.paginas[0]); // puedes permitir seleccionar qué página
                std::cout << "Primera página cargada en el BufferPool.\n";
            }
}

        else if (opcion == 8) {
            if (cd.paginas.empty()) {
                std::cout << "No hay páginas generadas. Por favor genera primero.\n";
                continue;
            }

            int numeroPagina;
            int operacion;
            cout << "Ingrese el número de página a cargar: ";
            cin >> numeroPagina;

            if (numeroPagina < 0 || numeroPagina >= cd.paginas.size()) {
                cout << "Número de página inválido.\n";
                continue;
            }

            cout << "Seleccione operación:\n1. Lectura\n2. Escritura\nOpción: ";
            cin >> operacion;
            bool esEscritura = (operacion == 2);

            bm.cargarPaginaAlBuffer(cd.paginas[numeroPagina], numeroPagina, esEscritura);

            
        }
         else if (opcion == 9) {
            cout << "\nPáginas cargadas actualmente en el BufferPool:\n";

            const auto& frames = bm.getFrames(); // Asumiendo que hiciste getFrames() público o tienes método wrapper

            for (const auto& frame : frames) {
                if (frame->getPageID() != -1) {
                    cout << "  Página ID: " << frame->getPageID()
                        << " (Frame ID: " << frame->getFrameID() << ", Pinned: "
                        << (frame->isPinned() ? "Sí" : "No") << ", PinCount: "
                        << frame->getPinCount() << ")\n";
                }
            }

            int pageID;
            cout << "\nIngrese el ID de la página que desea leer: ";
            cin >> pageID;

            auto frame = bm.getFrameByPageID(pageID);  // Asegúrate de tener este método en BufferManager

            if (frame) {
                const Pagina& pagina = frame->getPagina();
                const vector<string>& sectores = pagina.getSectores();  // Asegúrate de tener este getter

                cout << "\nContenido de la Página " << pageID << ":\n";

                for (const string& ruta : sectores) {
                    ifstream archivo(ruta);
                    cout << "  - Sector: " << ruta << "\n    ";

                    if (archivo.is_open()) {
                        string linea;
                        bool vacio = true;
                        while (getline(archivo, linea)) {
                            cout << linea << "\n    ";
                            vacio = false;
                        }
                        if (vacio) cout << "[Archivo vacío]\n";
                        archivo.close();
                    } else {
                        cout << "[No se pudo abrir el archivo]\n";
                    }
                }

                // Disminuir el pinCount y actualizar pinned
                frame->unpin();
                if (!frame->isPinned()) {
                    cout << "PinCount llegó a 0. Página desanclada.\n";
                }

            } else {
                cout << "No se encontró la página en el buffer pool.\n";

            /*auto& allFrames = bm.getFrames();
            bool encontrada = false;
            for (const auto& frame : allFrames) {
                if (frame->getPageID() == pageID) {
                    const Pagina& pagina = frame->getPagina();
                    cout << "\nContenido de la página " << pageID << ":\n";
                    for (const auto& ruta : pagina.sectores) {
                        cout << "  - " << ruta << ": ";
                        ifstream archivo(ruta);
                        string linea;
                        if (archivo.is_open()) {
                            getline(archivo, linea);
                            cout << linea << endl;
                            archivo.close();
                        } else {
                            cout << "[No se pudo leer]\n";
                        }
                    }

                    frame->unpin();
                    if (frame->getPinCount() == 0) {
                        cout << "\n→ Página desanclada (Pinned: No)\n";
                    } else {
                        cout << "\n→ PinCount reducido a " << frame->getPinCount() << endl;
                    }

                    encontrada = true;
                    break;
                }
            }

            if (!encontrada) {
                cout << "No se encontró la página con ID " << pageID << " en el buffer.\n";
            }*/
        }

        


    }
 else if(opcion == 10) {
    int subopcion;
    while (true) {
        cout << "\nESCRITURA\n";
        cout << "1. Insertar registro" << endl;
        cout << "2. Modificar registro" << endl;
        cout << "3. Eliminar registro" << endl;
        cout << "4. Volver al menú principal" << endl;
        cout << "Seleccione: ";
        cin >> subopcion;

        if (subopcion == 1) {

        std::vector<std::shared_ptr<Frame>> frames = bm.getBufferPool().getFrames();

        std::cout << "Páginas disponibles para escritura:\n";
        std::vector<int> escrituraIndices;

        for (size_t i = 0; i < frames.size(); ++i) {
            if (frames[i] && frames[i]->isDirty()) {
                std::cout << i << ". Página ID: " << frames[i]->getPageID() << "\n";
                escrituraIndices.push_back(i);
            }
        }

        if (escrituraIndices.empty()) {
            std::cout << "No hay páginas marcadas como escritura en el buffer pool.\n";
            return 0;  // o simplemente break;
        }

        int eleccion;
        std::cout << "Seleccione una página para insertar el registro: ";
        std::cin >> eleccion;

        if (eleccion < 0 || static_cast<size_t>(eleccion) >= frames.size() || !frames[eleccion]) {
            std::cerr << "Selección inválida.\n";
            return 0;
        }

        std::string registro;
        std::cin.ignore();  // Limpiar buffer
        std::cout << "Ingrese el contenido del registro: ";
        std::getline(std::cin, registro);

        Pagina& pagina = frames[eleccion]->getPaginaRef();
        const std::vector<std::string>& sectores = pagina.getSectores();

        bool escrito = false;

        for (const std::string& sectorPath : sectores) {
            std::ofstream sector(sectorPath, std::ios::app);  // append
            if (!sector.is_open()) {
                std::cerr << "No se pudo abrir el sector: " << sectorPath << "\n";
                continue;
            }

            sector.seekp(0, std::ios::end);
            std::streampos tam = sector.tellp();

            if (tam < 512) {  // Ajusta este límite si tienes un tamaño real
                sector << registro << "\n";
                escrito = true;
                std::cout << "Registro insertado en: " << sectorPath << "\n";
                break;
            }
        }

        if (!escrito) {
            std::cout << "No se pudo insertar el registro. Todos los sectores están llenos.\n";
            return 0;
        }

        // Actualizar flags
        frames[eleccion]->setDirty(false);
        frames[eleccion]->unpin();

        std::cout << "Estado actualizado: dirty = No, ";
        std::cout << "Pin count = " << frames[eleccion]->getPinCount() << ", ";
        std::cout << "Pinned = " << (frames[eleccion]->isPinned() ? "Sí" : "No") << "\n";

        // 🔼 Fin del bloque de inserción

        } else if (subopcion == 2) {
            std::vector<std::shared_ptr<Frame>> frames = bm.getBufferPool().getFrames();

std::cout << "Páginas disponibles para modificación:\n";
std::vector<int> escrituraIndices;

for (size_t i = 0; i < frames.size(); ++i) {
    if (frames[i] && frames[i]->isDirty()) {
        std::cout << i << ". Página ID: " << frames[i]->getPageID() << "\n";
        escrituraIndices.push_back(i);
    }
}

if (escrituraIndices.empty()) {
    std::cout << "No hay páginas marcadas como escritura en el buffer pool.\n";
    break;
}

int eleccion;
std::cout << "Seleccione una página: ";
std::cin >> eleccion;

if (eleccion < 0 || static_cast<size_t>(eleccion) >= frames.size() || !frames[eleccion]) {
    std::cerr << "Selección inválida.\n";
    break;
}

Pagina& pagina = frames[eleccion]->getPaginaRef();
const std::vector<std::string>& sectores = pagina.getSectores();

std::vector<std::pair<int, std::string>> registros; // <número, contenido>
int contador = 0;

// Enumerar todos los registros en todos los sectores
for (size_t i = 0; i < sectores.size(); ++i) {
    std::ifstream sector(sectores[i]);
    if (!sector.is_open()) {
        std::cerr << "No se pudo abrir el sector: " << sectores[i] << "\n";
        continue;
    }

    std::string linea;
    while (std::getline(sector, linea)) {
        if (!linea.empty()) {
            registros.push_back({contador, linea});
            std::cout << contador << ". " << linea << "\n";
            contador++;
        }
    }
    sector.close();
}

if (registros.empty()) {
    std::cout << "No hay registros en esta página para modificar.\n";
    break;
}

int regModificar;
std::cout << "Ingrese el número del registro a modificar: ";
std::cin >> regModificar;

if (regModificar < 0 || regModificar >= (int)registros.size()) {
    std::cerr << "Número de registro inválido.\n";
    break;
}

std::cin.ignore(); // limpiar buffer
std::string nuevoRegistro;
std::cout << "Ingrese el nuevo contenido del registro: ";
std::getline(std::cin, nuevoRegistro);

// Buscar y reemplazar en el archivo correcto
contador = 0;
bool modificado = false;

for (size_t i = 0; i < sectores.size(); ++i) {
    std::fstream sector(sectores[i], std::ios::in | std::ios::out);
    if (!sector.is_open()) continue;

    std::vector<std::string> lineas;
    std::string linea;

    while (std::getline(sector, linea)) {
        lineas.push_back(linea);
    }

    sector.clear();
    sector.seekp(0);
    sector.seekg(0);
    sector.close();

    // Abrir para reescritura
    std::ofstream rewrite(sectores[i], std::ios::trunc);
    if (!rewrite.is_open()) continue;

    for (size_t j = 0; j < lineas.size(); ++j) {
        if (contador == regModificar) {
            rewrite << nuevoRegistro << "\n";
            modificado = true;
        } else {
            rewrite << lineas[j] << "\n";
        }
        contador++;
    }

    rewrite.close();
    if (modificado) break;
}

if (modificado) {
    frames[eleccion]->setDirty(false);
    frames[eleccion]->unpin();

    std::cout << "Registro modificado correctamente.\n";
    std::cout << "Estado actualizado: dirty = No, ";
    std::cout << "Pin count = " << frames[eleccion]->getPinCount() << ", ";
    std::cout << "Pinned = " << (frames[eleccion]->isPinned() ? "Sí" : "No") << "\n";
} else {
    std::cout << "No se pudo modificar el registro.\n";
}

        } else if (subopcion == 3) {
            std::vector<std::shared_ptr<Frame>> frames = bm.getBufferPool().getFrames();

std::cout << "Páginas disponibles para eliminación:\n";
std::vector<int> escrituraIndices;

for (size_t i = 0; i < frames.size(); ++i) {
    if (frames[i] && frames[i]->isDirty()) {
        std::cout << i << ". Página ID: " << frames[i]->getPageID() << "\n";
        escrituraIndices.push_back(i);
    }
}

if (escrituraIndices.empty()) {
    std::cout << "No hay páginas marcadas como escritura en el buffer pool.\n";
    break;
}

int eleccion;
std::cout << "Seleccione una página para eliminar registros: ";
std::cin >> eleccion;

if (eleccion < 0 || static_cast<size_t>(eleccion) >= frames.size() || !frames[eleccion]) {
    std::cerr << "Selección inválida.\n";
    break;
}

Pagina& pagina = frames[eleccion]->getPaginaRef();
const std::vector<std::string>& sectores = pagina.getSectores();

std::vector<std::tuple<int, std::string, std::string>> registrosEnumerados;  // <num, contenido, ruta>
int contador = 0;

for (const std::string& sectorPath : sectores) {
    std::ifstream sector(sectorPath);
    if (!sector.is_open()) {
        std::cerr << "No se pudo abrir el sector: " << sectorPath << "\n";
        continue;
    }

    std::string linea;
    while (std::getline(sector, linea)) {
        if (!linea.empty()) {
            registrosEnumerados.emplace_back(contador, linea, sectorPath);
            std::cout << contador << ". " << linea << "\n";
            contador++;
        }
    }
    sector.close();
}

if (registrosEnumerados.empty()) {
    std::cout << "No hay registros para eliminar.\n";
    break;
}

int regEliminar;
std::cout << "Ingrese el número del registro a eliminar: ";
std::cin >> regEliminar;

if (regEliminar < 0 || regEliminar >= (int)registrosEnumerados.size()) {
    std::cerr << "Número de registro inválido.\n";
    break;
}

// Eliminar el registro de su sector
std::string sectorObjetivo = std::get<2>(registrosEnumerados[regEliminar]);
std::ifstream sectorIn(sectorObjetivo);
if (!sectorIn.is_open()) {
    std::cerr << "No se pudo abrir el archivo del sector.\n";
    break;
}

std::vector<std::string> registrosCompactados;
std::string linea;
int actual = 0;

while (std::getline(sectorIn, linea)) {
    if (!linea.empty()) {
        // Saltar el registro a eliminar
        if (actual != regEliminar) {
            registrosCompactados.push_back(linea);
        }
        actual++;
    }
}
sectorIn.close();

// Reescribir el archivo con los registros compactados
std::ofstream sectorOut(sectorObjetivo, std::ios::trunc);
if (!sectorOut.is_open()) {
    std::cerr << "No se pudo reescribir el sector.\n";
    break;
}

for (const auto& r : registrosCompactados) {
    sectorOut << r << "\n";
}
sectorOut.close();

std::cout << "Registro eliminado correctamente.\n";

// Actualizar estado de la página
frames[eleccion]->setDirty(false);
frames[eleccion]->unpin();

std::cout << "Estado actualizado: dirty = No, ";
std::cout << "Pin count = " << frames[eleccion]->getPinCount() << ", ";
std::cout << "Pinned = " << (frames[eleccion]->isPinned() ? "Sí" : "No") << "\n";

        } else if (subopcion == 4) {
            break;
        } else {
            cout << "Opción inválida.\n";
        }
    }
}

else if (opcion == 11) {

    std::string comando = "rm -rf \"disco sgbd\"";
    int resultado = system(comando.c_str());
    if (resultado == 0) {
        std::cout << "Disco eliminado exitosamente.\n";
    } else {
        std::cerr << "Error al eliminar el disco.\n";
    }

}




            else if(opcion == 12){
            break;
        }
    } 
    return 0;
}