#ifndef CONTROLADORDISCO_H
#define CONTROLADORDISCO_H

#include <vector>
#include <string>
#include <fstream>
#include "Pagina.h"

class ControladorDisco {
private:
    int platos;
    int pistas;
    int sectores;
    

public:
    std::vector<Pagina> paginas;
    ControladorDisco() = default;  
    ControladorDisco(int platos, int pistas, int sectores);
    void generarPaginas(int sectoresPorPagina);
    void mostrarPaginas() const;
    bool insertarRegistroEnPagina(Pagina& pagina, const std::string& registro) {
    for (const auto& rutaSector : pagina.sectores) {
        std::ifstream lector(rutaSector);
        std::string contenido((std::istreambuf_iterator<char>(lector)),
                               std::istreambuf_iterator<char>());
        lector.close();

        if (contenido.empty() || contenido.back() != '\n') {
            contenido += '\n';  // Asegura que el nuevo registro se agregue bien
        }

        std::ofstream escritor(rutaSector, std::ios::app);
        if (escritor) {
            escritor << registro << "\n";
            escritor.close();
            std::cout << "Registro insertado en " << rutaSector << "\n";
            return true;  // Insertado exitosamente
        }
    }

    std::cout << "No hay espacio en los sectores de esta página.\n";
    return false;
}


};

#endif
