#ifndef ESQUEMA_H
#define ESQUEMA_H

#include <string>
#include <fstream>
#include <iostream>
using namespace std;

class Esquema{
    public:
    //string nombreArchivoEsquema;
    Esquema();
    void inferirTipo();
    void agregarTabla(string, int);
    void imprimirEsquema();
};

#endif
