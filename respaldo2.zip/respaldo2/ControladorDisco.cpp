#include "ControladorDisco.h"
#include <iostream>
#include <sstream>

ControladorDisco::ControladorDisco(int p, int pi, int s)
    : platos(p), pistas(pi), sectores(s) {}

void ControladorDisco::generarPaginas(int sectoresPorPagina) {
    paginas.clear();

    int totalSectores = platos * 2 * pistas * sectores;
    int totalPaginas = (totalSectores + sectoresPorPagina - 1) / sectoresPorPagina;

    int countGlobal = 0;

    for (int pista = 1; pista <= pistas; ++pista) {
        for (int sector = 1; sector <= sectores; ++sector) {
            for (int plato = 1; plato <= platos; ++plato) {
                for (int superficie = 1; superficie <= 2; ++superficie) {
                    std::ostringstream ruta;
                    ruta << "disco sgbd/disco " << plato
                         << "/superficie " << superficie
                         << "/pista " << pista
                         << "/sector " << sector << ".txt";

                    if (paginas.empty() || paginas.back().obtenerSectores().size() >= sectoresPorPagina) {
                        paginas.push_back(Pagina());
                    }

                    paginas.back().agregarSector(ruta.str());
                    countGlobal++;
                }
            }
        }
    }

    std::cout << "Se generaron " << paginas.size() << " páginas con " << countGlobal << " sectores en total.\n";
}


void ControladorDisco::mostrarPaginas() const {
    for (size_t i = 0; i < paginas.size(); ++i) {
        std::cout << "\nPágina " << i << ":\n";
        paginas[i].mostrarSectores();
    }
}
