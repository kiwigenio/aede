#ifndef POLITICAREEMPLAZO_H
#define POLITICAREEMPLAZO_H

#include "Frame.h"
#include <memory>

class PoliticaReemplazo {
public:
    virtual ~PoliticaReemplazo() = default;
    virtual void registrarAcceso(int frameId) = 0;
    //virtual int seleccionarVictima() = 0;
    virtual int seleccionarVictima(const std::vector<std::shared_ptr<Frame>>& frames) = 0;

};

#endif