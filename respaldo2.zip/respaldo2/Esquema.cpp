#include "Esquema.h"

Esquema::Esquema(){
    ofstream archivo("esquema.txt", ios::app);
}

void Esquema::inferirTipo(){/*
    int esInt = 1, esDouble = 1, esBool = 1;
    for (int i = 0; i < cantidad; i++) {
        string v = muestras[i];
        if (esNulo(v)) continue;
        if (!esEntero(v)) esInt = 0;
        if (!esDecimal(v) && !esEntero(v)) esDouble = 0;
        if (!esBooleano(v)) esBool = 0;
    }
    if (esBool) return "boolean";
    if (esInt) return "integer";
    if (esDouble) return "double";
    return "string";
    */
}


void Esquema::agregarTabla(string nombreTabla, int nroCamposTabla){
    //ofstream esquema("esquema.txt", ios::app);
    ofstream archivo("esquema.txt");
    archivo << nombreTabla;
    for (int i = 0; i < nroCamposTabla; i++) {
        //string tipo = inferirTipo(muestras[i], muestraActual);
        //esquema << "#" << campos[i] << "#" << tipo;
        string temp;
        int tipoOpcion;
        string tipo;
        cout << "Ingrese nombre del campo: ";
        cin >> temp;
        cout << "Escoja tipo de campo: " << endl;
        cout << "1. boolean" << endl;
        cout << "2. integer" << endl;
        cout << "3. double" << endl;
        cout << "4. string" << endl;
        cout << "5. char" << endl;
        cin >> tipoOpcion;
        if(tipoOpcion == 1) tipo = "boolean";
        else if(tipoOpcion == 2) tipo = "integer";
        else if(tipoOpcion == 3) tipo = "double";
        else if(tipoOpcion == 4) tipo = "string";
        else if(tipoOpcion == 5) tipo = "char";
        archivo << "#" << temp << "#" << tipo;

    }
    archivo << endl;
    archivo.close();

}

void Esquema::imprimirEsquema(){
    std::ifstream archivo("esquema.txt");

    if (!archivo.is_open()) {
        std::cerr << "No se pudo abrir el archivo." << std::endl;
        return;
    }

    string linea;
    while (std::getline(archivo, linea)) {
        size_t pos = linea.find('#');  // Buscar la primera ocurrencia de '#'
        if (pos != string::npos) {
            string esquema = linea.substr(0, pos);  // Extraer hasta el primer '#'
            cout << esquema << endl;
        } else {
            cout << linea << endl;  // Si no hay '#', imprimir toda la línea
        }
    }

    archivo.close();
}